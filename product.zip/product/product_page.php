<?php
include 'connect.php';
session_start();
// Simulating a logged-in user (in real use, get from session)
$user_id = 1; // replace with actual logged-in user's ID
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shop Products</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .product-card {
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 16px;
            margin: 10px;
            width: 250px;
            display: inline-block;
            vertical-align: top;
            text-align: center;
        }
        .product-card img {
            width: 200px;
            height: 200px;
            object-fit: contain;
        }
    </style>
</head>
<body>
    <h2>Shop Products</h2>

    <?php
    $result = $conn->query("SELECT * FROM product");
    while ($row = $result->fetch_assoc()) {
        echo "
        <div class='product-card'>
            <img src='{$row['imageURL']}' alt='{$row['product_name']}'>
            <h3>{$row['product_name']}</h3>
            <p>{$row['description']}</p>
            <p><strong>RM {$row['price']}</strong></p>
            <form action='add_order.php' method='post'>
                <input type='hidden' name='product_id' value='{$row['product_id']}'>
                <input type='hidden' name='user_id' value='$user_id'>
                <label>Quantity:</label>
                <input type='number' name='quantity' value='1' min='1' max='{$row['stock']}' required>
                <br><br>
                <button type='submit'>Add to Cart</button>
            </form>
        </div>";
    }
    ?>
</body>
</html>
