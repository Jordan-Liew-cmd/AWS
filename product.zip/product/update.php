<?php
include 'connect.php';

$id = $_POST['product_id'];
$name = $_POST['product_name'];
$desc = $_POST['description'];
$price = $_POST['price'];
$stock = $_POST['stock'];

$sql = "UPDATE Products SET 
        product_name='$name', description='$desc', price=$price, stock=$stock 
        WHERE product_id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: display_products.php");
} else {
    echo "Error: " . $conn->error;
}
$conn->close();
?>
