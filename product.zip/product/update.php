<?php
include 'connect.php';

$id = $_POST['product_id'];
$name = $_POST['product_name'];
$desc = $_POST['description'];
$price = $_POST['price'];
$stock = $_POST['stock'];

// Check if a new image was uploaded
if (!empty($_FILES["image"]["name"])) {
    $targetDir = "img/";
    $imageName = basename($_FILES["image"]["name"]);
    $targetFilePath = $targetDir . $imageName;

    if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
        // Update with new image
        $sql = "UPDATE product SET 
                product_name='$name', description='$desc', price=$price, stock=$stock, imageURL='$targetFilePath'
                WHERE product_id=$id";
    } else {
        echo "Error uploading image.";
        exit;
    }
} else {
    // Update without changing image
    $sql = "UPDATE product SET 
            product_name='$name', description='$desc', price=$price, stock=$stock
            WHERE product_id=$id";
}

if ($conn->query($sql) === TRUE) {
    header("Location: display.php");
} else {
    echo "Error: " . $conn->error;
}
$conn->close();
?>
