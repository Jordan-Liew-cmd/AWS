<?php
$host = "your-rds-endpoint";
$port = "3306";
$dbname = "your-database-name";
$username = "your-username";
$password = "your-password";

// Connect
$conn = new mysqli($host, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
