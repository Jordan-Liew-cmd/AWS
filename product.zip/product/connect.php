<?php
$host = "lab1-db.cujnj6olak03.us-east-1.rds.amazonaws.com";
$port = "3306";
$dbname = "lab1";
$username = "main";
$password = "lab-password";

// Connect
$conn = new mysqli($host, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
