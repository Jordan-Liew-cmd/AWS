<?php
include 'connect.php';
$order_id = $_GET['id'];

$conn->query("DELETE FROM orderDetails WHERE order_id = $order_id");
$conn->query("DELETE FROM Orders WHERE order_id = $order_id");

header("Location: displayOrders.php");
?>
