<?php
include 'connect.php';
$id = $_GET['id'];
$conn->query("DELETE FROM product WHERE product_id = $id");
header("Location: display.php");
?>
