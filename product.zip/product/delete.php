<?php
include 'connect.php';
$id = $_GET['id'];
$conn->query("DELETE FROM Products WHERE product_id = $id");
header("Location: display_products.php");
?>
