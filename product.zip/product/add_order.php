<?php
include 'connect.php';

$product_id = $_POST['product_id'];
$user_id = $_POST['user_id'];
$quantity = $_POST['quantity'];

// Get product price
$result = $conn->query("SELECT price FROM product WHERE product_id = $product_id");
$product = $result->fetch_assoc();
$price = $product['price'];
$total = $price * $quantity;

// Insert into `Orders` table
$conn->query("INSERT INTO orders (user_id, order_date, total_amount) VALUES ($user_id, CURDATE(), $total)");
$order_id = $conn->insert_id;

// Insert into `orderDetails` table
$conn->query("INSERT INTO orderDetails (order_id, product_id, quantity, price) VALUES ($order_id, $product_id, $quantity, $price)");

echo "Order placed successfully! <a href='product_page.php'>Back to Products</a>";
?>
