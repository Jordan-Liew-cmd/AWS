<?php include 'connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h2>All Products</h2>
    <a href="index.html" class="button">Add New Product</a>
    <table>
        <tr>
            <th>ID</th><th>Name</th><th>Description</th><th>Price</th><th>Stock</th><th>Actions</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM Products");
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['product_id']}</td>
                <td>{$row['product_name']}</td>
                <td>{$row['description']}</td>
                <td>{$row['price']}</td>
                <td>{$row['stock']}</td>
                <td>
                    <a class='button' href='edit_product.php?id={$row['product_id']}'>Edit</a>
                    <a class='button' href='delete_product.php?id={$row['product_id']}' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                </td>
              </tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
