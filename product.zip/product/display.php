<?php include 'connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
<?php
if (isset($_GET['message'])) {
    $msg = '';

    switch ($_GET['message']) {
        case 'added':
            $msg = "✅ Product added successfully!";
            break;
        case 'updated':
$msg = "✏️ Product updated successfully!";
            break;
        case 'deleted':
            $msg = "🗑️ Product deleted successfully!";
            break;
    }

    if ($msg) {
        echo "<div class='alert success'>$msg</div>";
    }
}
?>

    <h2>All Products</h2>
    <a href="addProduct.html" class="button">Add New Product</a>
    <table>
        <tr>
            <th>Image</th><th>ID</th><th>Name</th><th>Description</th><th>Price</th><th>Stock</th><th>Actions</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM product");
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td><img src='{$row['imageURL']}' width='100'></td>
                <td>{$row['product_id']}</td>
                <td>{$row['product_name']}</td>
                <td>{$row['description']}</td>
                <td>{$row['price']}</td>
                <td>{$row['stock']}</td>
                <td>
                    <a class='button' href='edit.php?id={$row['product_id']}'>Edit</a>
                    <a class='button' href='delete.php?id={$row['product_id']}' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                </td>
            </tr>";
        }
        ?>
    </table>
</div>
</body>
</html>