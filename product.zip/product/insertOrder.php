<?php
include 'connect.php';

$user_id = 1; // Replace with session value later
$order_date = date('Y-m-d');
$total_amount = $_POST['total_amount']; // Calculate this from items

// Insert into Orders table
$conn->query("INSERT INTO Orders (user_id, order_date, total_amount) VALUES ($user_id, '$order_date', $total_amount)");
$order_id = $conn->insert_id;

// Insert into orderDetails table
$products = $_POST['products']; // Array of ['product_id' => X, 'quantity' => Y]
foreach ($products as $item) {
    $product_id = $item['product_id'];
    $quantity = $item['quantity'];

    $product = $conn->query("SELECT price FROM product WHERE product_id = $product_id")->fetch_assoc();
    $price = $product['price'];

    $conn->query("INSERT INTO orderDetails (order_id, product_id, quantity, price) 
                  VALUES ($order_id, $product_id, $quantity, $price)");
}

echo "Order placed successfully!";
$conn->close();
?>
