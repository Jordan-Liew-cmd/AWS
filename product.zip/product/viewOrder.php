<?php
include 'connect.php';
$order_id = $_GET['id'];

$order = $conn->query("SELECT * FROM Orders WHERE order_id = $order_id")->fetch_assoc();
echo "<h2>Order #{$order['order_id']}</h2>";
echo "<p>Date: {$order['order_date']} | Total: RM{$order['total_amount']}</p>";

$result = $conn->query("SELECT od.*, p.product_name FROM orderDetails od
                        JOIN product p ON od.product_id = p.product_id
                        WHERE od.order_id = $order_id");

echo "<table><tr><th>Product</th><th>Qty</th><th>Price</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['product_name']}</td>
        <td>{$row['quantity']}</td>
        <td>RM{$row['price']}</td>
    </tr>";
}
echo "</table>";
$conn->close();
?>
