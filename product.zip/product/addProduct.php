<?php
include 'connect.php';

$name = $_POST['product_name'];
$desc = $_POST['description'];
$price = $_POST['price'];
$stock = $_POST['stock'];
$imageURL = $_POST['imageURL'];

$targetDir = "img/";
$imageName = basename($_FILES["image"]["name"]);
$targetFilePath = $targetDir . $imageName;

if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
    $imageURL = $targetFilePath;

    $sql = "INSERT INTO product (product_name, description, price, stock, imageURL)
            VALUES ('$name', '$desc', $price, $stock, '$imageURL')";

    if ($conn->query($sql) === TRUE) {
        header("Location: display.php?message=updated");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "Error uploading image.";
}

$conn->close();
?>