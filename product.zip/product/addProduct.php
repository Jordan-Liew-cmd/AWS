<?php
include 'connect.php';

$name = $_POST['product_name'];
$desc = $_POST['description'];
$price = $_POST['price'];
$stock = $_POST['stock'];

$sql = "INSERT INTO Products (product_name, description, price, stock)
        VALUES ('$name', '$desc', $price, $stock)";

if ($conn->query($sql) === TRUE) {
    echo "Product added successfully";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
