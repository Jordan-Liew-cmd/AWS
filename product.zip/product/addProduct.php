<?php
include 'connect.php';

$name = $_POST['product_name'];
$desc = $_POST['description'];
$price = $_POST['price'];
$stock = $_POST['stock'];
$imageURL = $_POST['imageURL'];

$sql = "INSERT INTO product (product_name, description, price, stock, imageURL)
        VALUES ('$name', '$desc', $price, $stock, $imageURL)";

if ($conn->query($sql) === TRUE) {
    echo "Product added successfully";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
