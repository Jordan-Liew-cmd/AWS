<?php
include 'connect.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM product WHERE product_id = $id");
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h2>Edit Product</h2>
    <form action="update.php" method="post">
        <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
        <input type="text" name="product_name" value="<?php echo $row['product_name']; ?>" required>
        <textarea name="description" required><?php echo $row['description']; ?></textarea>
        <input type="number" name="price" step="0.01" value="<?php echo $row['price']; ?>" required>
        <input type="number" name="stock" value="<?php echo $row['stock']; ?>" required>
        <button type="submit">Update Product</button>
    </form>
</div>
</body>
</html>
