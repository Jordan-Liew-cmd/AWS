<?php
include 'connect.php';

$result = $conn->query("SELECT * FROM Orders");
echo "<h2>All Orders</h2><ul>";
while ($row = $result->fetch_assoc()) {
    echo "<li>
        Order #{$row['order_id']} - User ID: {$row['user_id']} - Date: {$row['order_date']} 
        - Total: RM{$row['total_amount']} 
        <a href='viewOrder.php?id={$row['order_id']}'>View</a>
        <a href='deleteOrder.php?id={$row['order_id']}' onclick='return confirm(\"Delete this order?\")'>Delete</a>
    </li>";
}
echo "</ul>";
$conn->close();
?>
